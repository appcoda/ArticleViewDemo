//
//  ArticleController.swift
//  Delicious
//
//  Created by Sean Choo on 4/27/16.
//  Copyright © 2016 Demo. All rights reserved.
//

import UIKit

class ArticleController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
