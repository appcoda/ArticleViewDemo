//
//  ArticleMenuView.swift
//  Delicious
//
//  Created by Sean Choo on 5/4/16.
//  Copyright © 2016 Demo. All rights reserved.
//

import UIKit

class ArticleMenuView: UIView {

    @IBOutlet weak var blurView: UIVisualEffectView!
    
}
